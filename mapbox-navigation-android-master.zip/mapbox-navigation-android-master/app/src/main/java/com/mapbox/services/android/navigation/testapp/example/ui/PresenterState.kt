package com.mapbox.services.android.navigation.testapp.example.ui

enum class PresenterState {
    SHOW_LOCATION,
    SEARCH,
    SHOW_ROUTE,
    NAVIGATE
}
